<?php

require_once('init/init.php');
global $session;
global $database; 
$user=$session->get_user_id();

$isSend=true;
$error_name=array();
if(isset($_POST["Bath"])){
    
if($_POST["Towels"]){
    $Towels = $_POST["Towels"];
    $prodName="Towels";
    $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Towels."','".$user."');";
    if(!$database->query($sql)){
       $isSend=false; 
    array_push($error_name,"Towels");
    }

    
}
if($_POST["shaving"]){
        $shaving = $_POST["shaving"];
        $prodName="shaving";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$shaving."','".$user."');";
        if(!$database->query($sql)){
    array_push($error_name,"shaving");
           $isSend=false; 
}}

if($_POST["shampoo"]){
        $shampoo = $_POST["shampoo"];
        $prodName="shampoo";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$shampoo."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
        array_push($error_name,"shampoo");
}
    
}
if($_POST["Soap"]){
        $Soap = $_POST["Soap"];
        $prodName="Soap";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Soap."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false;
        array_push($error_name,"Soap");
           
}
}
if($isSend==true)
    {
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
    }
    else
        {
        $arrlength = count($error_name);
$error_message="";
for($x = 0; $x < $arrlength; $x++) {
    $error_message=$error_message . $error_name[$x];
    $x+1==$arrlength ? $error_message=$error_message." " :$error_message=$error_message. ", ";
}
$error_message=$error_message. " has not Received.";
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","'.$error_message.'","error");';
  echo '}, 1000);</script>';
    } 

}
else if(isset($_POST["Bedroom"])){
$isSend=true;
$error_name=array();

if($_POST["Pillow"]){
        $Pillow = $_POST["Pillow"];
        $prodName="Pillow";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Pillow."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
            array_push($error_name,"Pillow");
}}
if($_POST["blanket"]){
        $blanket = $_POST["blanket"];
        $prodName="blanket";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$blanket."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
        array_push($error_name,"blanket");
}}
if($_POST["sheets"]){
        $sheets = $_POST["sheets"];
        $prodName="sheets";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$sheets."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
           array_push($error_name,"sheets");

}}
    if($isSend==true)
    {
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
    }
    else
    {
        $arrlength = count($error_name);
$error_message="";
for($x = 0; $x < $arrlength; $x++) {
    $error_message=$error_message . $error_name[$x];
    $x+1==$arrlength ? $error_message=$error_message." " :$error_message=$error_message. ", ";
}
$error_message=$error_message. " has not Received.";
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","'.$error_message.'","error");';
  echo '}, 1000);</script>';
    } 
}

else if(isset($_POST["service"])){
    if($_POST["time"] and $_POST["type"]!="not-option" and $_POST["note"]){
        $Time = $_POST["time"];
        $note = $_POST["note"];
        $type=$_POST["type"];
    $sql="INSERT INTO Maintance (date,user, notes,Type) VALUES ('".$Time."','".$user."','".$note."','".$type."');";
        if(!$database->query($sql)){
        echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
  echo '}, 1000);</script>';
        }
        else{
              echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
            
            
        }
    }
else{
            echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","You did not fill in all the details","error");';
  echo '}, 1000);</script>';

}
    
}



else if(isset($_POST["maintenance"])){
$user=$session->get_user_id();
$maintenances = $_POST['malfunction'];
$texts = $_POST['text'];
$type="maintenance";
$isSend=false;
$date=date("Y-m-d");
foreach (array_combine($maintenances, $texts) as $maintenance => $text){ 

    $sql="INSERT INTO Maintance (date,user, notes,Type) VALUES ('".$date."','".$user."','".$text."','".$maintenance."');";
        if($database->query($sql)){
           $isSend=true;
        }

}


if($isSend==true)
{
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
}
else
{
            echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
  echo '}, 1000);</script>';
}




}

?>


<!DOCTYPE html>
<html lang="en" >

<head>
    <style>

    </style>
  <meta charset="UTF-8">
  <title>Awesome Image Hover Pure CSS Part II</title>
  
  		<meta name="viewport" content="width=device-width, initial-scale=1"> 
  
      <link rel="stylesheet" href="../css/services_new/figure_modal.css">
      <link rel="stylesheet" href="../css/services_new/responsive_modal.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
 <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css'>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>

<body><br><br>
    <header id="gtco-header"  role="banner" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					                <nav id="bt-menu" class="bt-menu">
                    <a href="#" class="bt-menu-trigger"><span>Menu</span></a>
                    <ul>
                <li><a href="homePage.php">Home</a></li>
                <li><a href="breakfast.php">Meals</a></li>
                <li><a href="new_services.php">Services</a></li>
                <li><a href="newRest.php">Restaurant</a></li>
                <li><a href="tuktuk.php">Transportation</a></li>
                <li><a href="googleApi.html">Concierge</a></li>
                <li><a href="checkout.php">Check out</a></li>
                <li><a href="init/logout.php">Logout</a></li>
                    </ul>
                </nav>
                
     <form method="post" action="new_services.php">
           
    <div class="modal-overlay" style="z-index:1;">

  <div class="modal">
    
    <a class="close-modal">
      <svg viewBox="0 0 20 20">
        <path fill="#edd5d5" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
      </svg>
    </a><!-- close modal -->

    <div class="modal-content">

  <div class="centerbox"><br>
    <h1 class="head">Select Bath products</h1>
<div id="counter_content">
    <h3>Towels (max 5):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="Towels" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>
          <h3>Shaving kit (max 3):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="shaving" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>

                <h3>shampoo (max 5):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="shampoo" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>

                <h3>Soap (max 5):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="Soap" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>
        <button name="Bath" class="btn button" type="submit" >Send</button><br>
    </div>

  </div>
    </div><!-- content -->
    
  </div><!-- modal -->
        
</div><!-- overlay -->
</form>
<form method="post" action="new_services.php">

    <div class="modal-overlay1">

  <div class="modal1">
    
    <a class="close-modal1">
      <svg viewBox="0 0 20 20">
        <path fill="#edd5d5" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
      </svg>
    </a><!-- close modal -->

    <div class="modal-content1">
  <div class="centerbox">
    <h1 class="head">Select Bedroom items</h1>
<div id="counter_content">

    <h3>Pillow (max 5):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="Pillow" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>
  <h3>blanket  (max 3):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="blanket" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p><h3>bed sheets (max 3):</h3>
    <p style="position:relative;">
        <a id="minus1" class="minus" style="">-</a>
        <input name="sheets" style="" id="qty1" type="text" value="0" class="qty" />
        <a id="add1" class="add">+</a>
    </p>
        <button name="Bedroom" class="btn button" type="submit">Send<br></button>
      </div>
  </div>
    </div><!-- content -->
    
  </div><!-- modal -->
        
</div><!-- overlay -->
 </form>
 <form method="post" action="new_services.php">

     <div class="modal-overlay2">

  <div class="modal2">
    
    <a class="close-modal2">
      <svg viewBox="0 0 20 20">
        <path fill="#edd5d5" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
      </svg>
    </a><!-- close modal -->

    <div class="modal-content2">
  <div class="centerbox">
    <h1 class="head">Select Service type and time</h1>
<div id="counter_content">

<select id="soflow" name="type">
  <!-- This method is nice because it doesn't require extra div tags, but it also doesn't retain the style across all browsers. -->
  <option value="not-option">Type of service</option>
  <option value="Cleaning">Cleaning</option>
  <option value="Laundry">Laundry</option>
</select><br><br>

  <input type="datetime-local" name="time" class="time" value="2018-08-19T13:00:00" id="example-datetime-local-input" step="3600"><br><br>
	<textarea name="note" rows="4" id="txtarea" cols="50" placeholder="Pleasr write notes..." ></textarea>
        <button name="service" class="btn button" type="submit" >Send<br></button>
      </div>
  </div>
    </div><!-- content -->
    
  </div><!-- modal -->
        
</div><!-- overlay -->
 
 </form>
 <form method="post" action="new_services.php">

     <div class="modal-overlay3">

  <div class="modal3">
    
    <a class="close-modal3">
      <svg viewBox="0 0 20 20">
        <path fill="#edd5d5" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
      </svg>
    </a><!-- close modal -->
<br><br>
    <div class="modal-content3"><br><br>
  <div class="wrapper">
      <ul>
        <li>
            <p>Choose your malfunction:</p><br>
        </li>
        <li>
            <input type="checkbox" id="check1" name="malfunction[]" value="TV"/> <span>TV</span>
            <input type="text" name="text[]" class="manf_text" id="text1" disabled />

        </li>
        <li>
            <input type="checkbox" id="check2" name="malfunction[]" value="Conditioner"/> <span>Air-Conditioner</span>
            <input type="text" name="text[]" class="manf_text" id="text2" disabled/>

        </li>
        <li>
            <input type="checkbox" id="check3" name="malfunction[]" value="safe"/> <span>Safe</span>
            <input type="text" name="text[]" class="manf_text" id="text3" disabled/>

        </li>
        <li>
            <input type="checkbox" id="check4" name="malfunction[]" value="Door"/> <span>Door</span>
            <input type="text" name="text[]" class="manf_text" id="text4" disabled/>

        </li>
           <li>
            <input type="checkbox" id="check5" name="malfunction[]" value="Windows"/> <span>Windows</span>
            <input type="text" name="text[]" class="manf_text" id="text5" disabled/>

        </li>
    </ul>
    <button class="btn button" type="submit" name="maintenance" >Send<br></button>

</div>

      </div>
    </div><!-- content -->
    
  </div><!-- modal -->
        
</div><!-- overlay -->
</form>
 
  
<div class="content">
				<div class="grid">
					<figure class="effect-goliath">
						<img src="../images/toothbrush.png" alt="img23"/>
						<figcaption>
							<h2>Bath products <br><span>Towels, shaving kit etc.</span></h2>
					<button href="" data-modal="#modal2" class="modal__trigger first picbtn">Order now</button>
						</figcaption>			
					</figure>
					<figure class="effect-goliath">
						<img src="../images/make%20up%20room.png" alt="img24"/>
						<figcaption>
							<h2>Bed sheets <br><span>Pillow, blanket and bed sheet</span></h2>
					<button href="" data-modal="#modal2" class="modal__trigger sec picbtn">Order now</button>
						</figcaption>			
					</figure>
					<figure class="effect-goliath">
						<img src="../images/sheets.png" alt="img23"/>
						<figcaption>
							<h2>Cleaning services <br><span>Cleaning and laundering</span></h2>
					<button href="" data-modal="#modal2" class="modal__trigger third picbtn">Order now</button>
						</figcaption>			
					</figure>
					<figure class="effect-goliath">
						<img src="../images/laundary.png" alt="img24"/>
						<figcaption>
							<h2>Maintenance <br><span>Invite a technician to the room</span></h2>
					<button href="" data-modal="#modal2" class="modal__trigger Fourth picbtn">Order now</button>
						</figcaption>			
					</figure>
				</div>
			</div>
  
  

</body>
<script>

</script>
      <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js'></script>
	<script src="../js/borderMenu.js"></script>
    <script src="../js/classie.js"></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

		<script src="../js/services_new/figure.js"></script>
		<script src="../js/services_new/responsive_modal.js"></script>
        <script src="../js/services_new/checkbox.js"></script>

</html>



















