<?php

require_once('init/init.php');
global $session;
global $database; 

	if(isset($_POST["tuk"]))
	{
		$location = $_POST['loc'];
		$destination = $_POST['dest'];
		$numOfPass = $_POST['number'];
        $userName=$session->get_user_id();
		$timeDate= $_POST['TimeDate'];
		
        $newTimeDate=substr($timeDate, 0, 10);
		$timeDate = str_replace('T', ' ', $timeDate);
        $taxi = $_POST['switcheroo'];
        
        $newTimeDate=substr($timeDate, 0, 10);
        $check_valid_date="select checkInDate, checkOutDate from guestOrder where id=$userName";
        $check_valid_date_result=$database->query($check_valid_date);
        while($row=$check_valid_date_result->fetch_assoc()){
        $user_check_in=$row["checkInDate"];
        $user_check_out=$row["checkOutDate"];}
        
        if($user_check_in<=$newTimeDate and $user_check_out>=$newTimeDate){
                if($location!=$destination){     
                $tuktuksql ="select licenseNum, numberOfRides from tuktuks
                 WHERE licenseNum IN (SELECT licenseNum FROM tuktuks WHERE licenseNum NOT IN (select distinct tuktuk FROM tuktukOrders WHERE DateTime='$timeDate'))  order by numberOfRides;";
            
            
               $tuktuk = $database->query($tuktuksql);
        
                
               $myTuktuk=mysqli_fetch_assoc($tuktuk)["licenseNum"];
               $sql="INSERT INTO tuktukOrders (user,DateTime, location, destination, numOfPass,tuktuk,needTaxi) VALUES ('".$userName."','".$timeDate."','".$location."','".$destination."','".$numOfPass."','".$myTuktuk."','".$taxi."');";
               
                $updateRides="UPDATE tuktuks
                SET numberOfRides = numberOfRides+1
                WHERE licenseNum=$myTuktuk;";
                $database->query($updateRides);
                    
                        if($database->query($sql))
                        {
                	          echo '<script type="text/javascript">';
                  echo 'setTimeout(function () { swal("Your tuktuk has been oredered","Thank you for your patience","success");';
                  echo '}, 1000);</script>';
                       }
                		else{
                	        echo '<script type="text/javascript">';
                  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
                  echo '}, 1000);</script>';
                
                        }
        
               }

            else{
                  	        echo '<script type="text/javascript">';
          echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
          echo '}, 1000);</script>';
            }
        
}
else{
                		   echo '<script type="text/javascript">';
                echo 'setTimeout(function () { swal("You must select a valid dates","Try again","error");';
                echo '}, 1000);</script>';

}
       

	}
	
?>	

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Tuktuk order</title>
  <meta name="viewport" content="height=device-height, initial-scale=1">
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700'>
    
  <link rel="stylesheet" type="text/css" href="../css/tuktuk.css" />
 <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css'>
  
</head>

<body>
          
  
       <nav id="bt-menu" class="bt-menu">
                    <a href="#" class="bt-menu-trigger"><span>Menu</span></a>
                    <ul>
                <li><a href="homePage.php">Home</a></li>
                <li><a href="breakfast.php">Meals</a></li>
                <li><a href="new_services.php">Services</a></li>
                <li><a href="newRest.php">Restaurant</a></li>
                <li><a href="tuktuk.php">Transportation</a></li>
                <li><a href="googleApi.html">Concierge</a></li>
                <li><a href="checkout.php">Check out</a></li>
                <li><a href="init/logout.php">Logout</a></li>
                    </ul>
                </nav>
  <div class="content">
    <header>
      <div class="header-content">
      <h1><span class="taxi">Tuktuk</span>order</h1>
      </div>
      <div class="slanted"></div>
    </header>
        
    <section style="background-image: url(https://www.viewmastercms.com/assets/VMAPP_Yamaha_Golf_Car/image/ic/orig/HI_FLEET2_TEE_262_alt_punch2_No_Bottles_crop_001.jpg);background-size: cover;">

<form action="tuktuk.php" method="POST">

     
<select name="loc">
  <option value="">Choose your location</option>
  <option value="M1">M1</option>
  <option value="M2">M2</option>
  <option value="M3">M3</option>
  <option value="L">L</option>
</select>
     
<select name="dest">
  <option value="">Choose your destination</option>
  <option value="M1">M1</option>
  <option value="M2">M2</option>
  <option value="M3">M3</option>
  <option value="L">L</option>
</select>
<select name="number">
  <option value="">Number of people</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
</select>
<select name="switcheroo">
  <option value="">Do you need a taxi outside the hotel?</option>
  <option value="1">Yes</option>
  <option value="0">No</option>
</select>
          


  <input name="TimeDate" type="text" placeholder="Date and time" onfocus="(this.type='datetime-local')" step="900"><br><br>

    </section>
    <button class="sub" type="submit" name="tuk">Order</button>
  </div>
</div>
  <script src='https://use.fontawesome.com/c762b783bc.js'></script>
      </form>
  
</div>
</body>
        <script src="../js/borderMenu.js"></script>
        <script src="../js/classie.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</html>