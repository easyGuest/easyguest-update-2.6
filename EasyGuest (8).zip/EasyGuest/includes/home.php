<?php

require_once('init/init.php');
global $session;
global $database;

?>


<!DOCTYPE html>
<html>
    <head>
    <title>EasyGuest - Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/home.css">
</head>

<header>
    
        <?php
    $id=$session->get_user_id();
    $user_name="select name from Guests where id='$id'";
    $user_name_ans=$database->query($user_name);
    $name=$user_name_ans->fetch_assoc()['name'];
    if($session->is_login()){
        echo "<p>Hello, $name! | <a href='init/logout.php'>Logout</a></p>";}
    else
        echo "<div id='log'> no Welcome</div>";
        ?>

</header>
<body>

<header class="w3-display-container w3-wide bgimg w3-grayscale-min" id="home">
  <div class="w3-display-middle w3-text-white w3-center">
    <h1 class="w3-jumbo">EasyGuest</h1>
    <h2>Just order</h2>
  </div>
</header>
<main>
<nav>
<div class="w3-bottom w3-hide-small">
  <div class="w3-bar w3-white w3-center w3-padding w3-opacity-min w3-hover-opacity-off">
    <a href="#" style="width:16.66%" class="w3-bar-item w3-button">Home</a>
    <a href="breakfast.php" style="width:16.66%" class="w3-bar-item w3-button">Reservation to Meals</a>
    <a href="../includes/Services.php" style="width:16.66%" class="w3-bar-item w3-button">Services</a>
    <a href="../includes/newRest.php" style="width:16.66%" class="w3-bar-item w3-button">Restaurant</a>
    <a href="tuktuk.php" style="width:16.66%" class="w3-bar-item w3-button w3-hover-black">transportation</a>
    <a href="../includes/checkout.php" style="width:16.66%" class="w3-bar-item w3-button">Check out</a>

  </div>
</div>
</nav>
</main>


 
</body>
</html>
