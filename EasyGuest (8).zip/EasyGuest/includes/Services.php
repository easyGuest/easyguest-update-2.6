<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Services</title>
  
    <meta name="viewport" content="width=device-width, initial-scale=1">

  
<link rel="stylesheet" href="../css/services.css">


<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel='stylesheet prefetch' href='https://flatlogic.github.io/awesome-bootstrap-checkbox/bower_components/Font-Awesome/css/font-awesome.css'>
</head>

<body>

       <nav id="bt-menu" class="bt-menu">
                    <a href="#" class="bt-menu-trigger"><span>Menu</span></a>
                    <ul>
                <li><a href="homePage.php">Home</a></li>
                <li><a href="breakfast.php">Meals</a></li>
                <li><a href="new_services.php">Services</a></li>
                <li><a href="newRest.php">Restaurant</a></li>
                <li><a href="tuktuk.php">Transportation</a></li>
                <li><a href="googleApi.html">Concierge</a></li>
                <li><a href="checkout.php">Check out</a></li>
                <li><a href="init/logout.php">Logout</a></li>
                    </ul>
                </nav>

<h1 style="color:white;"><b>Services</b></h1>
<div class="content">
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Bath products</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h4><label>Towels (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[1]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[1]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
                    <h4><label>Shaving kit (max 3):</label></h4>

        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[2]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[2]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[2]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
          <h4><label>Shampoo (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[3]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[3]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[3]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
          <h4><label>Soap (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[4]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[4]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[4]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-warning" >Send <span class="glyphicon glyphicon-send"></span></button>      </div>
    </div>
  </div>
</div>
    
        <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Bed sheets</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h4><label>Pillow (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[5]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[5]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[5]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
          <h4><label>Blanket (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[6]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[6]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[6]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>
          <h4><label>Bed sheets (max 3):</label></h4>
        <div class="input-group">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" disabled="disabled" data-type="minus" data-field="quant[7]">
                  <span class="glyphicon glyphicon-minus"></span>
  </button>
  </span>
  <input type="text" name="quant[7]" class="form-control input-number" value="0" min="0" max="3">
  <span class="input-group-btn">
              <button type="button" class="btn btn-default btn-number" data-type="plus" data-field="quant[7]">
                  <span class="glyphicon glyphicon-plus"></span>
  </button>
  </span>
</div>          
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-warning" >Send <span class="glyphicon glyphicon-send"></span></button>      </div>
    </div>
  </div>
</div>
    
        <div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cleaning &amp; laundry</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <div class="form-group">
              <select class="form-control">
            <option value="" selected>Service type</option>
                  <option>Cleaning</option>
                  <option>Laundry</option> 
                </select>
           
      </div> 
  <label>Date and time</label>
  <div class="col-4">
    <input class="form-control" type="datetime-local" value="2011-08-19T13:45:00" id="example-datetime-local-input">
  </div>
           <label for="exampleTextarea">Notes</label>
    <textarea class="form-control" id="exampleTextarea" rows="3"></textarea>
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-warning" >Send <span class="glyphicon glyphicon-send"></span></button>
      </div>
    </div>
  </div>
</div>
    
    
     <div class="modal fade" id="exampleModal4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Maintenance</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <input type="text" class="form-control" id="text1" disabled placeholder="Notes">

               <div class="checkbox checkbox-success">
            <input id="check1" type="checkbox" name="malfunction[]">
            <label for="check1">TV</label>
          </div>
          

  <input type="text" class="form-control" id="text2" disabled placeholder="Notes" name="text[]">

            <div class="checkbox checkbox-success">
            <input id="check2" type="checkbox" name="malfunction[]">
            <label for="check2">Safe</label>
          </div>
  <input type="text" class="form-control" id="text3" disabled placeholder="Notes" name="text[]">

                         <div class="checkbox checkbox-success">
            <input id="check3" type="checkbox" name="malfunction[]">
            <label for="check3">Door</label>
          </div>
  <input type="text" class="form-control" id="text4" disabled placeholder="Notes" name="text[]">

            <div class="checkbox checkbox-success">
            <input id="check4" type="checkbox" name="malfunction[]">
            <label for="check4">Windows</label>
          </div>
          
  <input type="text" class="form-control" id="text5" disabled placeholder="Notes" name="text[]">

            <div class="checkbox checkbox-success">
            <input id="check5" type="checkbox" name="malfunction[]" >
            <label for="check5">Air-Conditioner</label>
          </div>
          
</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-warning" >Send <span class="glyphicon glyphicon-send"></span></button>
      </div>
    </div>
  </div>
</div>
				<div class="grid">
					<figure class="effect-goliath">
						<img src="../images/toothbrush.png" style="width:100%" alt="img23"/>
						<figcaption>
							<h2>Bath <span>Products</span></h2>
							<p>Order</p>
							<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">View more</a>
						</figcaption>			
					</figure>
					<figure class="effect-goliath">
						<img src="../images/sheets.png" style="width:100%" alt="img24"/>
						<figcaption>
							<h2>Bed <span>Sheets</span></h2>
							<p>Order</p>
							<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal2">View more</a>
						</figcaption>			
					</figure>
                    <figure class="effect-goliath">
						<img src="../images/make up room.png" style="width:100%" alt="img24"/>
						<figcaption>
							<h2>Cleaning <span>&amp;laundry</span></h2>
							<p>Order</p>
							<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal3">View more</a>
						</figcaption>			
					</figure>
                    <figure class="effect-goliath">
						<img src="https://tympanus.net/Development/HoverEffectIdeas/img/24.jpg" alt="img24"/>
						<figcaption>
							<h2><span>Maintenance</span></h2>
							<p>Order</p>
							<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal4">View more</a>
						</figcaption>			
					</figure>
				</div>
    </div>
</body>
<script>
    $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})
    </script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    <script src="../js/services.js"></script>
            <script src="../js/borderMenu.js"></script>
        <script src="../js/classie.js"></script>
</html>
