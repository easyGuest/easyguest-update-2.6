<?php

$isSend=true;
require_once('init/init.php');
global $session;
global $database; 

            
if(isset($_POST["maintenance"])){
$user=$session->get_user_id();
$maintenance = $_POST['malfunction'];

$type="maintenance";
$isSend=true;
$date=date("Y-m-d");
foreach ($maintenance as $malfunction){ 

    $sql="INSERT INTO Maintance (date,user, notes,Type) VALUES ('".$date."','".$user."','".$malfunction."','".$type."');";
        if(!$database->query($sql)){
           $isSend=false;
        }

}

if($_POST["note"]){
    $note=$_POST["note"];
    $sql="INSERT INTO Maintance (date,user, notes,Type) VALUES ('".$date."','".$user."','".$note."','".$type."');";
        if(!$database->query($sql)){
         $isSend=false;
        }
}

if($isSend==true)
{
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
}
else
{
            echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
  echo '}, 1000);</script>';
}




}
?>





<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Material Design - Checkbox</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet prefetch' href='http://cdn.materialdesignicons.com/1.1.70/css/materialdesignicons.min.css'>

      <link rel="stylesheet" href="../css/checkbox.css">

  
</head>

<body>
<form method="post" action="Services.php">


<div class="container">
	<h1>Please choose your malfunction</h1>
	<div class="wrap" style="margin-top:-25px;">
		<div class="material-checkbox blue">
			<input type="checkbox" id="cb1" name="malfunction[]" value="TV">
			<label class="check" for="cb1">TV</label>
		</div>
	</div>
	<div class="wrap">
		<div class="material-checkbox blue">
			<input type="checkbox" id="cb2" name="malfunction[]" value="Conditioner">
			<label class="check" for="cb2">Air-Conditioner</label>
		</div>
	</div>
	<div class="wrap">
		<div class="material-checkbox blue">
			<input type="checkbox" id="cb3" name="malfunction[]" value="Safe">
			<label class="check" for="cb3">Safe</label>
		</div>
	</div>
	<div class="wrap">
		<div class="material-checkbox blue">
			<input type="checkbox" id="cb4" name="malfunction[]" value="Door">
			<label class="check" for="cb4">Door</label>
		</div>
	</div>
	<div class="wrap">
		<div class="material-checkbox blue">
			<input type="checkbox" id="cb5" name="malfunction[]" value="Windows">
			<label class="check" for="cb5">Windows</label>
		</div>
	</div>
	<br><br>
	<div class="wrap" id="text">
	<textarea rows="2" cols="20" placeholder="Other..." name="note"></textarea>
	</div>
	<br>
	<div class="wrap">
	    <br>
		<button type="submit" class="button" name="maintenance">Send request</button>
        </div>
</div>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  </form>

    <script  src="../js/checkbox.js"></script>




</body>

</html>
