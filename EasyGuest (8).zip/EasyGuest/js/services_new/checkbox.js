/*
	Custom checkbox and radio button - Jun 18, 2013
	(c) 2013 @ElmahdiMahmoud 
	license: https://www.opensource.org/licenses/mit-license.php
*/   

$('input[name="malfunction[]"]').wrap('<div class="check-box"><i></i></div>');
$.fn.toggleCheckbox = function () {

    this.attr('checked', !this.attr('checked'));
        if ($(this).attr("checked")) {
            var idArr = $("input:checkbox").map(function(i, el) { return $(el).attr("id"); }).get();
            $(this).attr("id")
            if($(this).attr("id")=="check1")
                document.getElementById("text1").disabled = false;
            else if($(this).attr("id")=="check2")
                document.getElementById("text2").disabled = false;
            else if($(this).attr("id")=="check3")
                document.getElementById("text3").disabled = false;
            else if($(this).attr("id")=="check4")
                document.getElementById("text4").disabled = false;
            else if($(this).attr("id")=="check5")
                document.getElementById("text5").disabled = false;

    }
    else{
            if($(this).attr("id")=="check1")
                document.getElementById("text1").disabled = true;
            else if($(this).attr("id")=="check2")
                document.getElementById("text2").disabled = true;
            else if($(this).attr("id")=="check3")
                document.getElementById("text3").disabled = true;
            else if($(this).attr("id")=="check4")
                document.getElementById("text4").disabled = true;
            else if($(this).attr("id")=="check5")
                document.getElementById("text5").disabled = true;}
}
$('.check-box').on('click', function () {

    $(this).find(':checkbox').toggleCheckbox();
    $(this).toggleClass('checkedBox');
    

});

