var elements1 = $('.modal-overlay1, .modal1');

$('.sec').click(function(){
    window.scrollTo(0, 0);
    elements1.addClass('active');
    elements.removeClass('active');
    elements3.removeClass('active');
    elements2.removeClass('active');
});

$('.close-modal1').click(function(){
    elements1.removeClass('active');
});


var elements = $('.modal-overlay, .modal');

$('.first').click(function(){
    elements.addClass('active');
      elements1.removeClass('active');
    elements3.removeClass('active');
      elements2.removeClass('active');
});

$('.close-modal').click(function(){
    elements.removeClass('active');
});


var elements2 = $('.modal-overlay2, .modal2');

$('.third').click(function(){
        window.scrollTo(0, 0);
    elements2.addClass('active');
    elements.removeClass('active');
    elements1.removeClass('active');
    elements3.removeClass('active');
});

$('.close-modal2').click(function(){
    elements2.removeClass('active');
});

var elements3 = $('.modal-overlay3, .modal3');

$('.Fourth').click(function(){
        window.scrollTo(0, 0);
    elements3.addClass('active');
    elements.removeClass('active');
    elements2.removeClass('active');
    elements1.removeClass('active');
});

$('.close-modal3').click(function(){
    elements3.removeClass('active');
});
