$(function () {
    $('.add').on('click',function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal < 3) {console.log(currentVal);
            $qty.val(currentVal + 1);
          if(currentVal === 6){
            
          }
          
        }
    });
    $('.minus').on('click',function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {console.log(currentVal);
            $qty.val(currentVal - 1);
          if(currentVal <= 7){
            
          }
        }
    });
});

$(function () {
    $('.add').on('click',function(){
        var $qty=$(this).closest('p').find('.qty1');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal < 2) {console.log(currentVal);
            $qty.val(currentVal + 1);
          if(currentVal === 6){
            
          }
          
        }
    });
    $('.minus').on('click',function(){
        var $qty=$(this).closest('p').find('.qty1');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {console.log(currentVal);
            $qty.val(currentVal - 1);
          if(currentVal <= 7){
            
          }
        }
    });
});$(function () {
    $('.add').on('click',function(){
        var $qty=$(this).closest('p').find('.qty2');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal < 5) {console.log(currentVal);
            $qty.val(currentVal + 1);
          if(currentVal === 6){
            
          }
          
        }
    });
    $('.minus').on('click',function(){
        var $qty=$(this).closest('p').find('.qty2');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {console.log(currentVal);
            $qty.val(currentVal - 1);
          if(currentVal <= 7){
            
          }
        }
    });
});$(function () {
    $('.add').on('click',function(){
        var $qty=$(this).closest('p').find('.qty3');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal < 5) {console.log(currentVal);
            $qty.val(currentVal + 1);
          if(currentVal === 6){
            
          }
          
        }
    });
    $('.minus').on('click',function(){
        var $qty=$(this).closest('p').find('.qty3');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {console.log(currentVal);
            $qty.val(currentVal - 1);
          if(currentVal <= 7){
            
          }
        }
    });
});


function watchForHover() {
    var hasHoverClass = false;
    var container = document.body;
    var lastTouchTime = 0;

    function enableHover() {
        // filter emulated events coming from touch events
        if (new Date() - lastTouchTime < 500) return;
        if (hasHoverClass) return;

        container.className += ' hasHover';
        hasHoverClass = true;
    }

    function disableHover() {
        if (!hasHoverClass) return;

        container.className = container.className.replace(' hasHover', '');
        hasHoverClass = false;
    }

    function updateLastTouchTime() {
        lastTouchTime = new Date();
    }

    document.addEventListener('touchstart', updateLastTouchTime, true);
    document.addEventListener('touchstart', disableHover, true);
    document.addEventListener('mousemove', enableHover, true);

    enableHover();
}

watchForHover();