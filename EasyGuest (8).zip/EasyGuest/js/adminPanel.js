$("#toggle-menu").click(function(e) {
        e.preventDefault();
        $(".dashboard-wrapper").toggleClass("active");
});
