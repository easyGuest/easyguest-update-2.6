Created by Codrops

http://www.codrops.com

Integrate it for free in your personal or commercial projects, but don't republish or sell "as-is". Please contact us first if you want to create ports (for example WordPress or Joomla plugins).

Read more here: http://tympanus.net/codrops/licensing/