<?php


$servername = "localhost";
$username = "roird_guest";
$password = "12345";
$dbname = "roird_EasyGuest";

$conn=new mysqli($servername,$username,$password,$dbname);

session_start();

if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
    } 
	
	if(isset($_POST["tuk"]))
	{
		$location = $_POST['loc'];
		$destination = $_POST['dest'];
		$numOfPass = $_POST['number'];
		$userName=$_SESSION["user"];
		$timeDate= $_POST['TimeDate'];
		$timeDate = str_replace('T', ' ', $timeDate);
        $taxi = $_POST['switcheroo'];

       if($location!=$destination){     
        $tuktuksql ="select licenseNum, numberOfRides from tuktuks
         WHERE licenseNum IN (SELECT licenseNum FROM tuktuks WHERE licenseNum NOT IN (select distinct tuktuk FROM tuktukOrders WHERE DateTime='$timeDate'))  order by numberOfRides;";
    
    
       $tuktuk = $conn->query($tuktuksql);
       echo mysqli_num_rows($tuktuk);

        
       $myTuktuk=mysqli_fetch_assoc($tuktuk)["licenseNum"];
       $sql="INSERT INTO tuktukOrders (user,DateTime, location, destination, numOfPass,tuktuk,needTaxi) VALUES ('".$userName."','".$timeDate."','".$location."','".$destination."','".$numOfPass."','".$myTuktuk."','".$taxi."');";
       
        $updateRides="UPDATE tuktuks
        SET numberOfRides = numberOfRides+1
        WHERE licenseNum=$myTuktuk;";
        $conn->query($updateRides);
            
        if($conn->query($sql))
		    echo "<script type='text/javascript'>alert('Your tuktuk is orderd!');</script>";
		
		else{
		    echo "<script type='text/javascript'>alert('tuktuk not availble in this time');</script>";

        }

       }

    else{
        		    echo "<script type='text/javascript'>alert('Please choose valid location and destination!');</script>";

    }
		$conn->close(); 

	}
	
?>	




<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=0.4"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/tuktuk.css" />
				<link rel="stylesheet" type="text/css" href="css/style5.css" />
	      <link rel="stylesheet" href="css/style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

	<title>Choose your transport</title>
	</head>
	<body>
	
	<header>
	<nav id="bt-menu" class="bt-menu">
			<a href="#" class="bt-menu-trigger"><span>Menu</span></a>
	   <ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">Digital key</a></li>
				<li><a href="#">Services</a></li>
				<li><a href="#">Restaurant</a></li>
				<li><a href="#">Transportation</a></li>
				<li><a href="#">Check out</a></li>

	   </ul>
   </nav>

	</header>
	
	
	<div id="wraper">
	<h2 >Order a TUKTUK</h2>
<form action="tuktuk.php" method="POST">

<label class="mr-sm-2 cent" for="inlineFormCustomSelect" >Choose your location</label><br>
  <select name="loc" class="custom-select mb-2 mr-sm-2 mb-sm-0 cent" id="inlineFormCustomSelect">
    <option selected>MF1</option>
    <option value="MF2">MF2</option>
    <option value="MF3">MF3</option>
    <option value="MF4">MF4</option>
  </select><br><br>

  <label class="mr-sm-2 cent" for="inlineFormCustomSelect" >Choose your Destination</label><br>
  <select name="dest" class="custom-select mb-2 mr-sm-2 mb-sm-0 cent" id="inlineFormCustomSelect">
    <option selected>MF1</option>
    <option value="MF2">MF2</option>
    <option value="MF3">MF3</option>
    <option value="MF4">MF4</option>
  </select><br><br>
  
    <label class="mr-sm-2 cent" for="inlineFormCustomSelect" >Number of passengers</label><br>
  <select name="number" class="custom-select mb-2 mr-sm-2 mb-sm-0 cent" id="inlineFormCustomSelect">
    <option selected>1</option>
    <option value="1">2</option>
    <option value="2">3</option>
    <option value="3">4</option>
  </select><br><br>

 <label for="example-datetime-local-input" class="col-2 col-form-label cent">Date and time</label><br>
  <div class="col-10">
  <input name="TimeDate" id="asd" class="cent" type="datetime-local" value="2018-08-19T13:45:00" id="example-datetime-local-input" step="900" name="rideTime"><br><br>

</div>


  <div class="changer switcheroo-wrapper">
		<input class="btn-toggle" type="radio" name="switcheroo" value="1" checked/>
	  <label class="bs-bet-type-label">Need Taxi</label>
	  <input class="btn-toggle btn-subdued" type="radio" name="switcheroo" value="0"/><label class="btn-toggle">Don't need taxi</label>
	    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

</div>

  <button type="submit" class="btn btn-secondary cent" name="tuk" id="sub">send request</button>

</form>

</div>
</body>
			<script src="js/borderMenu.js"></script>
		<script src="js/modernizr.custom.js"></script>
        <script src="js/classie.js"></script>

		
</html>